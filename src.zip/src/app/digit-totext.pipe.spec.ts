import { DigitTotextPipe } from './digit-totext.pipe';

describe('DigitTotextPipe', () => {
  it('create an instance', () => {
    const pipe = new DigitTotextPipe();
    expect(pipe).toBeTruthy();
  });
});
